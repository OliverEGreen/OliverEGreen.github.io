Ready, version 1.03 (21 October 2026)

Ready Condensed widened to 124 %, vertical stems kept at full weight, spacing and kerning
measured again. For typed values, key labels, menu rows and codes.

Weights: Light 300, Book 350, Regular 400, Medium 500.
UPM 1000, cap height 700, x-height 520, 178 characters.
Figures are proportional by default (tnum for tabular).
Alternates: ss01 plain 1, ss02 closed 4, ss03 plain 7, ss04 long-slash 0, ss05 plain 0,
ss06 original C64 figures; zero for the long-slash 0.

New in 1.03: outlines saved as exact cubic curves (OpenType CFF), so the 5-unit rounding of
every corner, notch and tail stays smooth.
Files: .otf for installing, .woff2 for the web.
Capitals, figures and punctuation from C64 Keyboard by Levente Szabadkai (CC0).
Licence: CC0 1.0.
