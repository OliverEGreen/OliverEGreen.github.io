Ready Condensed, version 1.02 (21 October 2026)

C64 keycap capitals (C64 Keyboard by Levente Szabadkai, CC0) with a new lowercase drawn in
the same construction. For titles, body, labels, hints and table data.

Weights: Light 300, Book 350, Regular 400, Medium 500.
UPM 1000, cap height 700, x-height 520, 178 characters.
Figures are tabular by default (pnum for running text).
Alternates: ss01 plain 1, ss02 closed 4, ss03 plain 7, ss04 long-slash 0, ss05 plain 0,
ss06 original C64 figures; zero for the long-slash 0.

New in 1.02: outlines saved as exact cubic curves (OpenType CFF), so the 5-unit rounding of
every corner, notch and tail stays smooth.
Files: .otf for installing, .woff2 for the web.
Licence: CC0 1.0.
